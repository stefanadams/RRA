#!/bin/bash

../dataimport/items.pl ../dataimport/items.2007.txt 
for i in 128 357 358 360 361 362 396 452 77 7 83 88; do ./moreinfo.pl $i jpg; done
./moreinfo.pl 478 pdf
./moreinfo.pl 479 pdf
./moreinfo.pl 480 pdf
