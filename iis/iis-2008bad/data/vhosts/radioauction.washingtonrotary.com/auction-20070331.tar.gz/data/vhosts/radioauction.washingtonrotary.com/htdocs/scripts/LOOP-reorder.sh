#!/bin/bash

while [ 1 ]; do read i j; ./reorder.pl $i $j; done
