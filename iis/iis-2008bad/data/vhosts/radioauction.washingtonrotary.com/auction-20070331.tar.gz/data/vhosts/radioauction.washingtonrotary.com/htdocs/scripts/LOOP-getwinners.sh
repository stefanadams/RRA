#!/bin/bash

while [ 1 ]; do read i; ./report.pl $i; done
